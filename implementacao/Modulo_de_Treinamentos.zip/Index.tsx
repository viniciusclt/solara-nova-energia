import { MainMenu } from "@/components/MainMenu";

const Index = () => {
  return <MainMenu />;
};

export default Index;

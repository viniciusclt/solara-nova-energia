## Contexto da Empresa: Cactos – Soluções em Energia

**Nome da Empresa:** Cactos – Soluções em Energia
**Fundação:** 2019, Rio de Janeiro
**Negócio Principal:** Soluções completas de energia renovável, com foco em geração fotovoltaica.

**Missão:** Ajudar famílias e empresas a reduzirem custos mensais de forma sustentável, gerando previsibilidade, conforto, desenvolvimento empresarial e minimizando preocupações com a conta de luz.

**Visão:** Ser referência em independência energética, impulsionada por uma equipe engajada e colaborativa, transformando vidas através da tecnologia e de um mundo mais sustentável.

**Valores:** Cultura de Resultados, Colaboração, Honestidade, Excelência.

**Áreas de Atendimento:** Preferencialmente Rio de Janeiro (capital) e cidades próximas na Região Metropolitana. Outras cidades do RJ para faturas acima de R$2.000. Projetos (sem instalação) fora do estado do RJ.

**Diferenciais:**
* 100% de aprovação de clientes (até Jul/2025).
* Cobertura de propostas equivalentes (garantia de preço).
* Seguro de instalação + responsabilidade civil; seguro anual opcional do sistema.
* Engenharia própria em todas as etapas (visita técnica, projeto, layout, instalação e testes).
* Análise por drone com maquete 3D no PV*Sol (>90% de assertividade na estimativa de geração).
* Projetos 100% personalizados.
* Monitoramento online permanente e relatórios semanais opcionais.
* Suporte técnico e pós-vendas.

**Tipos de Sistema Oferecidos:** On-grid, Híbrido, Off-grid.

**Benefícios ao Cliente:** Economia de até 95% na fatura, payback típico de 2 anos, proteção contra inflação energética, valorização do imóvel, marketing verde, redução de CO2.

**Garantias:** Módulos (15 anos produto, 30 anos performance), Inversor (10-25 anos), Mão de obra Cactos (1 ano).

**Financiamento:** Parcerias com BV, Santander, Sicredi.

**Soluções Complementares:** Aquecimento de Água para Banho, Aquecimento de Piscinas, Carregadores Veiculares (WallBox).

## Requisitos Iniciais para o Programa de Pontos:

**Objetivo Principal:** Bonificar clientes com pontos que possam ser trocados por produtos, viagens, restaurantes, descontos em serviços e mais.

**Formas de Ganhos de Pontos (Exemplos Fornecidos):**
* Aquisição de produtos ou serviços (da Cactos).
* Indicação de novos clientes.
* Avaliação no Google.
* Vídeo de feedback.

**Tipos de Recompensas (Exemplos Fornecidos):**
* Produtos.
* Viagens.
* Restaurantes.
* Descontos em serviços.
* Outros (a serem definidos).

**Considerações:** O programa deve se alinhar com a missão, visão e valores da Cactos, incentivando a sustentabilidade e a satisfação do cliente. Deve ser fácil de usar e gerenciar, e oferecer recompensas atrativas para o público-alvo da Cactos (famílias e empresas que buscam soluções de energia renovável).


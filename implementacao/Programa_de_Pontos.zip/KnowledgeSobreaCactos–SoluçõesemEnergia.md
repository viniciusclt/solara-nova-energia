# 

# **Sobre a Cactos – Soluções em Energia**

Fundada em 2019 no Rio de Janeiro, a Cactos fornece soluções completas de energia renovável, com foco principal em geração fotovoltaica.

**MISSÃO**

Nossa missão é ajudar famílias e empresas a reduzirem seus custos mensais de forma sustentável, gerando mais previsibilidade, conforto, desenvolvimento empresarial e fazendo com que a conta de luz seja menos uma preocupação.

---

**VISÃO**

Ser referência em independência energética, impulsionado por uma equipe engajada e colaborativa, que transforma a vida de milhares de famílias e empresas através da tecnologia e de um mundo mais sustentável.

---

**NOSSOS VALORES**

Nossos valores são a base do nosso trabalho e o que esperamos de cada membro do nosso time:

* **Cultura de Resultados:** Focamos em **atingir e superar metas**, buscando sempre a **eficácia** e a **excelência** na entrega. Queremos resultados que impulsionem o crescimento.  
* **Colaboração:** Acreditamos que **juntos somos mais fortes**. Trabalhamos em equipe, compartilhando conhecimento e nos apoiando para alcançar objetivos comuns.  
* **Honestidade:** Agimos com **transparência**, **integridade** e **ética** em todas as interações. Construímos relações de **confiança** com clientes e colegas.  
* **Excelência:** Buscamos constantemente o **melhor em tudo o que fazemos**. É a paixão por aprimoramento contínuo e a entrega de **alta qualidade** em cada detalhe.

## **Áreas de atendimento**

Atendemos preferencialmente:

• Rio de Janeiro (capital)

• Cidades próximas na Região Metropolitana

Outras Cidades do RJ (para faturas acima de R$2.000)

# **Diferenciais Cactos**

* 100% de aprovação de clientes até jul/2025.  
* Cobertura de qualquer proposta equivalente\* (garantimos igualar ou superar preço quando todos os entregáveis forem equivalentes \- \*Sujeito a apresentação da proposta concorrente para comparação).  
* Seguro de instalação \+ responsabilidade civil incluídos; seguro anual opcional do sistema (0,99 % a.a.).  
* Engenharia própria em todas as etapas (visita técnica, projeto, layout, instalação e testes).  
* Realização de análise por drone com criação de maquete 3D no PV\*Sol o que traz uma estimativa de geração com \> 90 % de assertividade.  
* Projetos 100 % personalizados.  
* Monitoramento online permanente e opção de relatórios semanais.  
* Suporte técnico e time de pós-vendas para sanar dúvidas.

# **Time Cactos**

CEO \- Vinícius

SDR \- Lilian e Bia (IA)

Closer  \- Tatyana

Projetista \- 

Customer Service CS \- 

Administração/Financeiro \- Camila

# **Páginas e sites**

[www.cactossolucoesemenergia.com.br](http://www.cactossolucoesemenergia.com.br) (antigo)  
[www.energiacactos.com.br](http://www.energiacactos.com.br) (em desenvolvimento)  
Instagram: @[cactos.se](http://cactos.se)   
Facebook: [https://www.facebook.com/cactossolucoesemenergia](https://www.facebook.com/cactossolucoesemenergia)   
email: [contato@energiacactos.com.br](mailto:contato@energiacactos.com.br)  
Whatsapp: 21 97681-1065

## **Tipos de sistema que oferecemos**

| Tipo | Descrição | Quando indicar |
| ----- | ----- | ----- |
| On-grid | Conectado à rede; excedente vira crédito | Residências/comércios/indústrias |
| Híbrido | On-grid \+ baterias de lítio | Locais que precisam de backup em quedas de energia |
| Off-grid | 100 % independente da rede | Sítios, fazendas e áreas sem concessionária |

Componentes-padrão  
• Módulos (também chamados de painéis ou placas) de 585 (dependendo do caso pode chegar até 700Wp) dos fabricantes Astronergy, Risen, DAH, Canadian, Longi, etc.

• Inversor string ou micro-inversores (Solis, Sungrow, SolarEdge, Hoymiles, Enphase, NEP)

• Estruturas p/ telha cerâmica, fibrocimento, metálica, laje ou solo

• String-box CC/CA, DPS, disjuntores e cabeamento solar (quando usado no inversor string, microinversor não se faz necessário)

• (Opcional) Banco de baterias nos sistemas híbridos ou offgrids

**Processo (passo a passo real Cactos)**

Etapa | Responsável | Prazo médio

Aceite da pré-proposta | Cliente | —

Visita técnica | Eng. Cactos | 4 d

Projeto \+ ART | Engenharia | 13 d

Homologação na concessionária | Cactos | 15 – 30 d

Recebimento de material | Logística | 7 d

Instalação | Equipe própria | 3 d

Troca do relógio | Concessionária | 4 d

Total estimado | — | ≈ 50 dias

| Etapa | Responsável  | Prazo médio |
| :---- | :---- | :---- |
| Aceite da pré-proposta | Cliente  | \- |
| Visita técnica | Eng. Cactos | \- |
| Projeto \+ ART | Engenharia | 13 dias |
| Homologação na concessionária | Light | 15 – 30 dias |
| Recebimento de material | Logística | 7 dias |
| Instalação | Equipe própria | 1,5 dias a cada 8 módulos |
| Troca do relógio | Concessionária | 4 dias |
| Total estimado |  | ≈ 50 dias |

**Benefícios ao cliente**

Economia de até 95 % na fatura (varia conforme tarifa e consumo).  
Payback típico: aproximadamente 2 anos.  
Proteção contra inflação energética.  
Valorização do imóvel e marketing verde.  
Redução \~800 kg CO₂/ano para cada 9 kWp instalado (equiv. 65 árvores/ano).

**Garantias**

Item | Prazo

* Módulos – Garantia de 15 anos e garantia de performance de 30 anos  
* Inversor | 10 anos para inversores strings a 15 anos para microinversores e 25 anos para Enphase.  
* Mão de obra Cactos | 1 ano incluído

**Financiamento**

• Parcerias com BV, Santander, Sicredi (12 – 144×; carência até 120 d).

• TIR típica ≥ 50 % a.a. (caso ENCANTO).

Soluções Térmicas e Complementares

## **1\. Aquecimento de Água para Banho**

Coletor | Características | Indicação

Placa plana | Robusto, menor custo inicial | Locais de alta insolação

Tubo a vácuo | ± 30 % mais eficiente | Regiões frias ou sombreadas e/ou maior eficiência no sistema

• Reservatórios em inox; isolamento PU.

• Controlador eletrônico de temperatura.

• Vida útil média 15 anos.

# **2\. Aquecimento de Piscinas**

Método | Vantagens | Observações

Coletor solar | OPEX próximo de zero mais barato| Precisa área \~50 % da piscina

Bomba de calor | Opera em dias nublados | Consome energia (pode usar FV) mais caro

## **3\. Carregadores Veiculares (WallBox)**

• Potências: 7, 11 e 22 kW (monofásico/trifásico).

• Padrão Tipo 2 – IEC 62196-2.

• Integração opcional ao fotovoltaico (carregamento com excedente).

Instalação e/ou venda de Wallbox;

Uso residencial ou comercial, podendo ser individual ou coletivo

FAQ Comercial & Técnico

## **1\. Qual o prazo de retorno?**

2 anos (1,5 a 3 anos) em médias residenciais/comerciais. 

## **2\. A Cactos cobre propostas concorrentes?**

Sim. Igualamos ou superamos o preço quando os entregáveis são equivalentes (equipamentos, garantia, seguro, pós-venda).

## **3\. Quais garantias tenho?**

• Módulos: 15 anos contra defeitos / 30 anos performance ≥ 87 %.

• Inversor: 10 anos para string, 15 anos para micro-inversor e 25 anos para enphase.

• Serviços Cactos: 1 ano.

• Seguro opcional: danos elétricos, força maior, roubo (0,99 % a.a.).

## **4\. Preciso de manutenção recorrente?**

É recomendado realizar limpeza 1 – 2×/ano ou sob alerta do monitoramento. A Cactos oferta uma manutenção preventiva completa para uma maior vida útil segurança e performance do sistema.

A manutenção preventiva conta com: Limpeza com produtos especiais para painéis solares, verificações: estruturais, equipotencialização, aterramento, proteções CA e CC, reaperto dos parafusos de disjuntores. 

## **5\. O sistema funciona em apagão ou falta de luz?**

Sistemas on-grid desligam como medida de segurança; para backup use solução híbrida com baterias.

## **6\. Posso usar créditos em outro imóvel?**

Sim, pela compensação de energia (Res. ANEEL 1.059/2023) sob mesma titularidade e concessionária de energia.

## **7\. Como é feito o projeto?**

Temos a opção de projeto detalhado feito com drone, gerando uma maquete 3d, possibilitando uma visibilidade do sistema antes mesmo de instalado, além de uma simulação via software que calcula a geração de hora em hora para todos os dias do ano, levando em consideração todos os fatores de perda, como sombreamento, inclinação, orientação entre outras, o que garante uma assertividade de mais de 90%.

## **8\. A Cactos oferece pós-venda?**

Sim: suporte remoto semanal, alertas, vídeos e PDFs explicativos; atendimento em até 24 h úteis.

## **9\. Quais documentos preciso para fechar?**

RG, CPF/CNPJ, contas de luz recente, comprovante de endereço e, em caso de financiamento, comprovante de renda ou balanço.

## **10\. A Cactos atende fora do estado RJ?**

Somente com projetos (sem instalação).

## **11\. O sistema funciona em dias nublados ou chuvosos?**  

Produz menos (≈ 30 – 60 % da potência), mas continua gerando. Os créditos acumulados nos meses ensolarados compensam a diferença.

## **12\. Preciso de baterias para zerar a conta?**  

Não. Baterias são indicadas apenas para backup em quedas de energia ou para objetivos de autonomia total (sistema híbrido/off-grid).

## **13\. Posso expandir o sistema no futuro?**  

Sim, desde que haja área disponível e capacidade no quadro elétrico. A expansão exige nova homologação na concessionária.

## **14\. O que acontece se a ANEEL mudar as regras?**  

Instalações homologadas mantêm direito adquirido conforme Lei 14.300/2022. Ajustes de tarifa fio-B já são considerados nos estudos.

## **16\. E se meu telhado for fibrocimento, metálico ou laje?**  

Utilizamos estruturas específicas para cada tipo. Fazemos verificação e em laje, suportes com lastro ou chumbadores.

## **17\. Existe seguro contra raio, vendaval ou roubo?**  

Sim. Seguro opcional (0,99 % a.a.) cobre danos elétricos, força maior, roubo/furto e perda de geração.

## **18\. O sistema faz barulho ou vibração?**  

Não. Painéis são silenciosos; e dependendo do modelo do inversor pode emitir \< 40 dB (semelhante a um ventilador).

## **19\. Posso usar créditos em outro imóvel ou condomínio?**  

Sim, via compensação de energia na mesma titularidade e área de concessão (Res. ANEEL 1.059/2023).

## **20\. Preciso de licença ambiental ou alvará?**  

Residências não precisam. Projetos comerciais de grande porte podem exigir anuência municipal; a Cactos orienta caso a caso.

## **21\. Qual o prazo total do projeto até gerar energia?**  

Média de 50 dias corridos: projeto, homologação, instalação e troca do medidor.

## **22\. O que acontece se eu vender o imóvel?**  

Pode levar o sistema ou vender junto com o imovel. Créditos acumulados podem ser transferidos ao novo proprietário ou para outra unidade sua, em caso de encerramento da unidade.

## **23\. IPTU ou ICMS têm redução?**  

Alguns municípios oferecem “IPTU Verde”. ICMS é isento para sistemas ≤ 1 MW conforme Convênio ICMS 16/2015. Verificamos caso a caso.

